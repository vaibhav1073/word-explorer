export const containerStyle = {
  display: "flex",
  flexDirection: { xs: "column", sm: "column", md: "row", lg: "row" },
  flexWrap: "wrap",
  mb: 2,
};
