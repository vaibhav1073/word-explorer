export const  box1={
    display: "flex",
    flexDirection: "row",
    justifyContent: "center",
    
    backgroundSize: "contain",
    backgroundRepeat:"no-repeat",
    backgroundPosition:"right",
    height:"60vh",
    mb:3,
  }

  export const  typographyStyle={ borderRight: "2px solid black", display: "inline",color:"#0476c1",fontWeight:"bolder" }