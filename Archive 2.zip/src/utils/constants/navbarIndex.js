export const pathIndex={
    "/":"0",
    "/explore":"1",
    "/quiz":"2"
}