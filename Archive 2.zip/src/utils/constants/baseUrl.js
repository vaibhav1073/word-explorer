export const baseUrl="https://restcountries.com/v3.1";
export const queryUrl="/all?fields=name,flags,population,cca3,region,area,continents,capital,currencies"

export const baseCountryUrl="https://restcountries.com/v3.1/"

// export const = /name/india?fullText=true
