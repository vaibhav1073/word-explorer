export const questions=[
    {
     "id": 1,
     "question": "What is this quiz about?",
     "answer": "This generates a small quiz to test your countries knowledge"
    },
    {
     "id": 2,
     "question": "What topics will be asked in this quiz?",
     "answer": "You will be asked questions based on countries' continents, capitals, flags and currencies."
    },
    {
     "id": 3,
     "question": "How many questions will be there in this quiz",
     "answer": "With a minimum of three questions you can yourself choose the size of the quiz."
    }
   ]