export const box1 = {
  display: "flex",
  flexDirection: "column",

  background: "linear-gradient(to bottom,#fff,rgba(113, 212, 250, 0.6))",
  minHeight: "100vh",
};
